#include "LPC17xx.h"                    // Device header
#include "GPIO_LPC17xx.h"               // Keil::Device:GPIO


void delay_init(){
	
	LPC_TIM1->PR= 25000-1;
	LPC_TIM1->MCR = 7;

	
}


void delay_ms(unsigned int ms){
	
		
	LPC_TIM1->IR=1;
	
	LPC_TIM1->TC=0;
	
	LPC_TIM1->MR0=ms;
	
	LPC_TIM1->TCR=1;
	
	while(! (LPC_TIM1->IR & 1)  );
		
}

