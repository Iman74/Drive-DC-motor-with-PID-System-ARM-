

extern void pwm_init();
extern int set_angle(unsigned char x);