


extern void delay_init();


extern void delay_ms(unsigned int ms);