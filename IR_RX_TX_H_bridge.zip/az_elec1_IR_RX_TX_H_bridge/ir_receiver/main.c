
#include "LPC17xx.h"                    // Device header
#include "GPIO_LPC17xx.h"               // Keil::Device:GPIO

#include "stdio.h"

#include "servo_motor_driver.h"

#include "delay.h"

#include "stdio.h"
int stdout_putchar (int ch);
int stdout_init (void);
int uart1_init (void);
int main(){
	int i;
	
 // pwm_init();
	uart1_init() ;
	//delay_init();
	stdout_init();
	
	stdout_putchar('O');
	while(1){

	
		

	}

}