#include "PIN_LPC17xx.h"                // Keil::Device:PIN
#include "LPC17xx.h"                    // Device header






void pwm_init(){
	
	
	PIN_Configure(2,3,PIN_FUNC_1,PIN_PINMODE_TRISTATE,PIN_PINMODE_NORMAL);
	
	LPC_PWM1->PR=125-1;
	
	LPC_PWM1->MR0=500-1;
	
	LPC_PWM1->MR4=100-1;
	
	LPC_PWM1->MCR=2;
	
	LPC_PWM1->PCR = 1<<12;
	
	LPC_PWM1->TCR=1;
}

int set_angle(unsigned char x){
	
	if(x>=0 && x<=180)	{
		LPC_PWM1->MR4=80+16*x/18;
		return 1;
	}else return 0;

}




