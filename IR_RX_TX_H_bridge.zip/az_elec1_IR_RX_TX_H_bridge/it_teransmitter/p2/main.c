#include "LPC17xx.h"                    // Device header
#include "RTE_Device.h"                 // Keil::Device:Startup

extern int stdout_init ();
extern int stdout_putchar (int ch);
//extern int stdin_init ();
//extern int stdin_getchar (int ch);
uint8_t hi[23]="Electrical Engineering";
int i ;

void UARTSend( char *BufferPtr, uint32_t Length );
int main (){
	char j=0;
	stdout_init ();
	while(1){
//stdout_putchar((uint8_t )LPC_UART0->RBR);
		j++;
		UARTSend(&j,1);
		for(i=0;i<10000000;i++);
	}
return 0;
}


void UARTSend( char *BufferPtr, uint32_t Length )
{
	while ( Length != 0 )
    {
	  stdout_putchar( *BufferPtr);
	  BufferPtr++;
	  Length--;
					for(i =0;i<=10000;i++);
	}
}