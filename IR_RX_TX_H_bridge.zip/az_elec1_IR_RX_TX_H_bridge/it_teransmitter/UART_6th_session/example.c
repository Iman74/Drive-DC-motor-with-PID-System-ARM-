





void func(int x){



}
