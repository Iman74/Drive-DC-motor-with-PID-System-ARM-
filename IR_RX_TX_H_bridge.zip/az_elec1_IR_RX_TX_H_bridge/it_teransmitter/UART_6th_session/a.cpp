#include "LPC17xx.h"                    // Device header
#include "stdio.h"

extern int stdout_init (void); 
int j;


void function1(){

	 char *a = new char(0);
	
	(*a)++;
	


}




int main(){
int i;
	
	//initialize
	
	stdout_init();
	
	
	function1();

	function1();
	
	
 while(1){
 //update
 for(i=0;i<=10000000;i++);
 printf("salam\n");

 }

}




