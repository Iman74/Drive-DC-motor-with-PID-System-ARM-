




void func(int x){



}

