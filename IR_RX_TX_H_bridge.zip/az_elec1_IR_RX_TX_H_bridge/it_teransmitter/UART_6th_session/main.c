#include "LPC17xx.h"                    // Device header
#include "stdio.h"

extern int stdout_init (void); 

int stdout_putchar (int ch);
int main(){
int i;
	char j=0;
	
	//initialize
	
	stdout_init();
	

	
 while(1){
 //update
	 j++;
 for(i=0;i<=10000000;i++);
 stdout_putchar(j);

 }

}




